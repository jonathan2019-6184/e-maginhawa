<?php		
	$con = mysqli_connect('localhost','root','121900','donation') or die(mysqli_error($con));
	date_default_timezone_set("Asia/Manila");
?>
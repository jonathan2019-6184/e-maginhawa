
<head>
    <meta charset="UTF-8">
    <title>E-Maginhawa</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="../../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="../../css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="../../css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <link href="../../js/morris/morris-0.4.3.min.css" rel="stylesheet" type="text/css" />
    <link href="../../css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <link href="../../css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="../../css/select2.css" rel="stylesheet" type="text/css" />
    <script src="../../js/jquery-1.12.3.js" type="text/javascript"></script>
</head>